=====================
django-public-project
=====================

Django Public Project (DPP) is a custom CMS for making large public projects, political processes and enquiry commissions
more transparent.

Current languages available: EN | DE


Documentation
=============
Read more about DPP in the ReadTheDocs documentation:

* http://django-public-project.readthedocs.org/

Getting Help/Contact
====================
There is a Google Group you can use for asking questions or giving suggestions:

* http://groups.google.com/d/forum/django-public-project

Feel free to get in touch on Twitter or follow for updates on new releases:

* https://twitter.com/DjPublicProject
